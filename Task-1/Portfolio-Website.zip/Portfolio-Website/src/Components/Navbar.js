import '../Components/Navbar.css'

function Navbar(){
    return (
     <>
    <div className="container" >
        <a>Home</a>
        <a >Projects</a>
    </div>
     </>
    );
}

export default Navbar
